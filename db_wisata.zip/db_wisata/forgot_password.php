<?php
include 'koneksi.php';
include 'PHPMailer/src/PHPMailer.php';
include 'PHPMailer/src/SMTP.php';
include 'PHPMailer/src/Exception.php';

$email = $username = '';
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['forgot_password'])) {
    $email = $_POST["email"];
    $username = $_POST["username"];

    // Use prepared statements to prevent SQL injection
    $check_user_query = $conn->prepare("SELECT * FROM user WHERE email = ? AND username = ?");
    $check_user_query->bind_param("ss", $email, $username);
    $check_user_query->execute();
    $check_user_result = $check_user_query->get_result();

    if ($check_user_result->num_rows == 1) {
        $verification_code = mt_rand(100000, 999999);

        $update_code_query = $conn->prepare("UPDATE user SET reset_code = ? WHERE email = ? AND username = ?");
        $update_code_query->bind_param("iss", $verification_code, $email, $username);
        $update_code_result = $update_code_query->execute();

        if ($update_code_result) {
    // Kirim email dengan kode verifikasi
    $mail = new PHPMailer\PHPMailer\PHPMailer();
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $email; // Change to your Gmail address
    $mail->Password = 'uclhiqvjoayaskik'; // Change to your Gmail password
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('your-email@gmail.com', 'Your Name');
    $mail->addAddress($email, $username);

    $mail->isHTML(true);
    $mail->Subject = 'Reset Password Verification Code';
    $mail->Body = 'Your verification code is: ' . $verification_code;

    if ($mail->send()) {
        header("Location: reset_password.php?email=$email&username=$username&code_sent=true");
        exit();
    } else {
        $error_message = "Failed to send email. Please try again.";
    }
} else {
    $error_message = "Failed to update verification code. Please try again.";
}
    } else {
        $error_message = "Username or email is incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="img/logo2/logokecil2.png">
    <title>Lupa Password</title>
    <!-- Tambahkan stylesheet sesuai kebutuhan Anda -->
    <style>
    /* Tambahkan stylesheet sesuai kebutuhan Anda */
    @import url('css/stylelogin.css');
    @import url('css/styleutama.css');
    </style>
</head>
<body>
    <div id="background-container"></div>
    <div id="content">
        <a href="view_publik.php"><img src="img/logo2/logoetam2.png" alt="Logo" id="logo"></a>
        <div id="top-right-links">
            <a href="tentang.php">About Us</a>
            <a href="kontak_kita.php">Contact</a>
        </div>
    </div>
    <div class="grid">
        <form method="POST" class="form login"><div class="judul"><a href="forgot_password.php" 
            class="b">Forgot Password</a></div>
            <?php
            // Tambahkan bagian ini untuk menampilkan pesan kesalahan
            if (!empty($error_message)) {
                echo '<p style="color: red; text-align: center;">' . $error_message . '</p>';
            }
            ?>
            <div class="form__field">
                <label for="email">
                    <svg class="icon">
                        <use xlink:href="#icon-envelope"></use>
                    </svg>
                    <span class="hidden">Email</span>
                </label>
                <input type="email" id="email" name="email" value="<?php echo $email; ?>" placeholder="Email" required>
            </div>
            <div class="form__field">
                <label for="username">
                    <svg class="icon">
                        <use xlink:href="#icon-user"></use>
                    </svg>
                    <span class="hidden">Username</span>
                </label>
                <input type="text" id="username" name="username" value="<?php echo $username; ?>" placeholder="Username" required>
            </div>
            <div class="form__field">
                <input type="submit" value="Send Verification Code" name="forgot_password">
            </div><hr class="divider2"><p class="text--center">
                Remember your password? <a href="login.php" class="blue-link">Sign in</a>
                <svg class="icon">
                    <use xlink:href="#icon-arrow-right"></use>
                </svg>
            </p>
        </form>
    </div>
    <svg xmlns="http://www.w3.org/2000/svg" class="icons">
        <symbol id="icon-arrow-right" viewBox="0 0 1792 1792">
            <path
                d="M1600 960q0 54-37 91l-651 651q-39 37-91 37-51 0-90-37l-75-75q-38-38-38-91t38-91l293-293H245q-52 0-84.5-37.5T128 1024V896q0-53 32.5-90.5T245 768h704L656 474q-38-36-38-90t38-90l75-75q38-38 90-38 53 0 91 38l651 651q37 35 37 90z" />
        </symbol>
        <symbol id="icon-user" viewBox="0 0 1792 1792">
            <path
                d="M1600 1405q0 120-73 189.5t-194 69.5H459q-121 0-194-69.5T192 1405q0-53 3.5-103.5t14-109T236 1084t43-97.5 62-81 85.5-53.5T538 832q9 0 42 21.5t74.5 48 108 48T896 971t133.5-21.5 108-48 74.5-48 42-21.5q61 0 111.5 20t85.5 53.5 62 81 43 97.5 26.5 108.5 14 109 3.5 103.5zm-320-893q0 159-112.5 271.5T896 896 624.5 783.5 512 512t112.5-271.5T896 128t271.5 112.5T1280 512z" />
        </symbol>
        <symbol id="icon-envelope" viewBox="0 0 24 24">
        <path d="M21 5H3c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zM12 13L3 8V7l9 5 9-5v1l-9 5zm0-5L3 3h18l-9 5z"/>
    </symbol>
    </svg>
    <script src="js/utama3.js"></script>
    <script src="js/utama4.js"></script>
</body>
</html>
