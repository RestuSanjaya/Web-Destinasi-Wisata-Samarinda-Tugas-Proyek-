<?php
// Sertakan koneksi.php
include 'koneksi.php';

session_start();

// Periksa apakah pengguna sudah login
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
}
?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Tambah Tempat Wisata</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <link rel="shortcut icon" type="image/x-icon" href="img/logo2/logokecil2.png">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/gijgo.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style6.css">
    <link rel="stylesheet" href="css/style3.css">
    <link rel="stylesheet" href="css/style4.css">
    <link rel="stylesheet" href="css/style5.css">
    <link rel="stylesheet" href="css/stylebanner2.css">
    <!-- <link rel="stylesheet" href="css/responsive.css"> -->
</head>

<body>
    <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->

    <!-- header-start -->
    <header>
        <div class="header-area">
            <div id="sticky-header" class="main-header-area">
                <div class="container-fluid">
                    <div class="header_bottom_border">
                        <div class="row align-items-center">
                            <div class="col-xl-2 col-lg-2">
                                <div class="logo">
                                    <a href="view_admin.php">
                                        <img src="img/logo2/logoetam2.png" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="main-menu d-none d-lg-block">
                                    <nav>
                                        <ul id="navigation">
                                            <li><a class="active" href="view_admin.php">Home</a></li>
                                            <li><a href="destinasi_wisata_admin.php">Destinasi</a></li>
                                            <li><a href="kategori_wisata_admin.php">Kategori Wisata <i class="ti-angle-down"></i></a>
                                                <ul class="submenu">
                                                    <?php
                                                    include 'backendkategori.php';
                                                    // Fetch categories from the database
                                                    $categories = getCategories();
                                                    // Counter untuk menghitung jumlah kategori yang sudah ditampilkan
                                                    $categoryCount = 0;
                                                    // Loop through the categories and generate menu items, stopping after 6 categories
                                                    foreach ($categories as $category) {
                                                    // Check if the category count has reached 6
                                                        if ($categoryCount >= 6) {
                                                        break; // Keluar dari loop jika sudah mencapai 6 kategori
                                                    }
                                                    // Tambahkan kategori ke dalam elemen <li>
                                                    echo '<li><a href="halaman_kategori_admin.php?id_kategori=' . $category['id_kategori'] . '">' . $category['nama_kategori'] . '</a></li>';
                                                    // Tingkatkan hitungan kategori
                                                    $categoryCount++;
                                                }
                                            ?>
                                            <li><center><a href="kategori_wisata_admin.php">- View All -</a></center></li>
                                        </ul>
                                    </li>
                                    <li><a class="" href="tentang_admin.php">About</a></li>
                                    <li><a href="kontak_kita_admin.php">Contact</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <form action="search_admin.php" method="POST">
                        <input type="text" name="search_query" placeholder="Cari Tempat Wisata...">
                        <a href="#">
                            <button type="submit">
                                <i class="fa fa-search">Search</i>
                            </a>
                        </button>
                    </form>
                    <div class="profile-logo">
                        <a class="logout-link">
                            <button class="logo-button">
                                <img src="img/profile2/user.png" alt="User Logo">
                            </button>
                        </a>
                        <div class="dropdown">
                            <div class="dropdown-content">
                                <?php
                                // Tampilkan username jika sudah diset
                                if (isset($username)) {
                                    echo "<p>Halo, <strong>" . htmlspecialchars($username) . "</strong> </p>";
                                }
                            ?>
                            <a href="logout.php" class="logout-link">
                                <div class="logout-button">
                                    <img src="img/profile2/logout.png" alt="Logout Logo">Logout</div></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</header>


<?php
include 'koneksi.php';

function add($nama_wisata, $gambar, $id_kategori, $deskripsi, $folder_gambar, $gambar2, $gambar3, $gambar4, $gambar5, $gambar6, $gambar7, $gambar8, $gambar9, $info, $alamat) 
{
    global $conn;

    // Sanitize input data
    $nama_wisata = mysqli_real_escape_string($conn, $nama_wisata);
    $deskripsi = mysqli_real_escape_string($conn, $deskripsi);
    $info = mysqli_real_escape_string($conn, $info);
    $alamat = mysqli_real_escape_string($conn, $alamat);

    // Check if the attraction already exists
    $check_sql = "SELECT * FROM wisata WHERE nama_wisata = ?";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "s", $nama_wisata);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);

    if (mysqli_num_rows($check_result) > 0) {
        return "Tempat Wisata sudah ada dalam database.";
    }

    // Insert attraction data into the database
    $sql = "INSERT INTO wisata (nama_wisata, gambar, id_kategori, deskripsi, folder_gambar, gambar2, gambar3, gambar4, gambar5, gambar6, gambar7, gambar8, gambar9, info, alamat) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssissssssssssss", $nama_wisata, $gambar, $id_kategori, $deskripsi, $folder_gambar, $gambar2, $gambar3, $gambar4, $gambar5, $gambar6, $gambar7, $gambar8, $gambar9, $info, $alamat);

        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            return true;
        } else {
            return 'Error adding the attraction: ' . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt);
    } else {
        return 'Error in preparing the statement: ' . mysqli_error($conn);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_wisata = htmlspecialchars($_POST['nama_wisata']);
    $deskripsi = htmlspecialchars($_POST['deskripsi']);
    $alamat = htmlspecialchars($_POST['alamat']); // Menangkap nilai alamat
    $folder_gambar = isset($_POST['folder_gambar']) ? $_POST['folder_gambar'] : "";
    $info = isset($_POST['info']) ? $_POST['info'] : "";

    $uploadDir = 'img/place/';
    $gambar = $_FILES['gambar']['name'];
    $target_file = $uploadDir . basename($gambar);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $validExtensions = array("jpg", "jpeg", "png", "gif");

    if (!in_array($imageFileType, $validExtensions)) {
        $error_message = 'Invalid file type. Please upload a valid image.';
    } else {
        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
            $id_kategori = $_POST['id_kategori'];
            $gambar2 = isset($_FILES['gambar2']['name']) ? $_FILES['gambar2']['name'] : "";
            $gambar3 = isset($_FILES['gambar3']['name']) ? $_FILES['gambar3']['name'] : "";
            $gambar4 = isset($_FILES['gambar4']['name']) ? $_FILES['gambar4']['name'] : "";
            $gambar5 = isset($_FILES['gambar5']['name']) ? $_FILES['gambar5']['name'] : "";
            $gambar6 = isset($_FILES['gambar6']['name']) ? $_FILES['gambar6']['name'] : "";
            $gambar7 = isset($_FILES['gambar7']['name']) ? $_FILES['gambar7']['name'] : "";
            $gambar8 = isset($_FILES['gambar8']['name']) ? $_FILES['gambar8']['name'] : "";
            $gambar9 = isset($_FILES['gambar9']['name']) ? $_FILES['gambar9']['name'] : "";
            // Tambahkan variabel gambar tambahan yang diperlukan sesuai kebutuhan
            $result = add($nama_wisata, $gambar, $id_kategori, $deskripsi, $folder_gambar, $gambar2, $gambar3, $gambar4, $gambar5, $gambar6, $gambar7, $gambar8, $gambar9, $info, $alamat); // Menyertakan alamat ke dalam pemanggilan fungsi add()

            if ($result === true) {
                $result_message = "Tempat Wisata berhasil ditambahkan";
            } elseif ($result === false) {
                $error_message = "Terjadi kesalahan saat menambahkan Tempat Wisata";
            } else {
                $duplicate_message = $result;
            }
        } else {
            $error_message = 'Error uploading the file.';
        }
    }
}

mysqli_close($conn);
?>

<div class="popular_destination_area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section_title text-center mb_70">
                    <h3 class="teksslider_a">Tambahkan Tempat Wisata</h3>
                    <?php 
                    if (isset($error_message)) {
                        echo '<p style="color: red;">' . htmlspecialchars($error_message) . '</p>';
                    } elseif (isset($result_message)) {
                        echo '<p style="color: green;">' . htmlspecialchars($result_message) . '</p>';
                        echo '<p style="color: green;">Silahkan Cek Tempat Wisata Yang Sudah Di Tambahkan <a href="more-places-admin.php"><u style="color: blue;">Di Sini.</u></a></p>';
                    } elseif (isset($duplicate_message)) {
                        echo '<p style="color: orange;">' . htmlspecialchars($duplicate_message) . '</p>';
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="row">
    <form id="category-form" action="add_wisata.php" method="POST" enctype="multipart/form-data" class="form">
    <div class="form-left">
        <div class="form-group">
            <label for="nama_wisata">Nama Wisata:</label>
            <input id="nama_wisata" type="text" name="nama_wisata" class="form-control" placeholder="Masukkan Nama Wisata" required>
        </div>

        <div class="form-group">
            <label for="alamat">Alamat Wisata:</label>
            <input id="alamat" type="text" name="alamat" class="form-control" placeholder="Masukkan Alamat Wisata" required>
        </div>

        <div class="form-group">
            <label for="id_kategori">Kategori Wisata:</label>
            <select id="id_kategori" name="id_kategori" class="form-control" required>
                <option value="">Pilih Kategori</option>
                <?php
                // Include koneksi.php untuk menginisialisasi koneksi
                include 'koneksi.php';

                // Query untuk mendapatkan kategori dari tabel kategori
                $kategori_query = "SELECT id_kategori, nama_kategori FROM kategori";
                $kategori_result = mysqli_query($conn, $kategori_query);

                // Periksa apakah query berhasil dijalankan
                if ($kategori_result && mysqli_num_rows($kategori_result) > 0) {
                    // Tampilkan opsi kategori
                    while ($row = mysqli_fetch_assoc($kategori_result)) {
                        echo '<option value="' . $row['id_kategori'] . '">' . $row['nama_kategori'] . '</option>';
                    }
                } else {
                    // Tampilkan pesan jika tidak ada kategori yang tersedia
                    echo '<option disabled selected>Tidak ada kategori tersedia</option>';
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="info">Tentang Wisata:</label>
            <textarea id="info" name="info" class="form-control" placeholder="Masukkan Tentang Wisata"></textarea>
        </div>

        <div class="form-group">
            <label for="folder_gambar">Nama Folder Gambar:</label>
            <input id="folder_gambar" type="text" name="folder_gambar" class="form-control" placeholder="Masukkan Nama Folder Gambar">
        </div>

            <div class="form-group">
            <label for="deskripsi">Keterangan Singkat:</label>
            <textarea id="deskripsi" name="deskripsi" class="form-control" placeholder="Masukkan Keterangan Singkat" required></textarea>
        </div>

    
    </div>

    <div class="form-right">
        <div class="form-group">
            <label for="gambar">Gambar Utama:</label>
            <input id="gambar" type="file" name="gambar" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar2">Gambar 1:</label>
            <input id="gambar2" type="file" name="gambar2" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar3">Gambar 2:</label>
            <input id="gambar3" type="file" name="gambar3" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar4">Gambar 3:</label>
            <input id="gambar4" type="file" name="gambar4" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar5">Gambar 4:</label>
            <input id="gambar5" type="file" name="gambar5" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar6">Gambar 5:</label>
            <input id="gambar6" type="file" name="gambar6" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar7">Gambar 6:</label>
            <input id="gambar7" type="file" name="gambar7" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar8">Gambar 7:</label>
            <input id="gambar8" type="file" name="gambar8" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar9">Gambar 8:</label>
            <input id="gambar9" type="file" name="gambar9" class="form-control-file" accept="">
        </div>
    </div>

    <div class="form-group">
        <button id="submit-btn" type="submit" class="btn btn-primary">Tambah Wisata</button>
    </div>
</form>

</div>
</div>
</div>




<footer class="footer">    
        <div class="copy-right_text">
            <div class="container">
                <div class="footer_border"></div>
                <div class="row">
                    <div class="col-xl-12">
                        <p class="copy_right text-center">
                           
 &copy;<script>document.write(new Date().getFullYear());</script> This Website is Samarinda Tourism 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>


  <!-- Modal -->
  <div class="modal fade custom_search_pop" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="serch_form">
            <input type="text" placeholder="Search" >
            <button type="submit">search</button>
        </div>
      </div>
    </div>
  </div>
    <!-- link that opens popup -->
<!--     
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://static.codepen.io/assets/common/stopExecutionOnTimeout-de7e2ef6bfefd24b79a3f68b414b87b8db5b08439cac3f1012092b2290c719cd.js"></script>

    <script src=" https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"> </script> -->
    <!-- JS here -->
    <script src="js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/ajax-form.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/scrollIt.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/nice-select.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/gijgo.min.js"></script>
    <script src="js/slick.min.js"></script>
   

    
    <!--contact js-->
    <script src="js/contact.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <script src="js/jquery.form.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/mail-script.js"></script>


    <script src="js/main.js"></script>
    <script>
        $('#datepicker').datepicker({
            iconsLibrary: 'fontawesome',
            icons: {
             rightIcon: '<span class="fa fa-caret-down"></span>'
         }
        });
    </script>
</body>

</html>
