<?php
include 'koneksi.php';

function getAttractions($conn, $limit = 12, $offset = 12) {
    global $conn;

    $attractions = array();

    // Set the limit of attractions per page
    $limit = 12;
    $sql = "SELECT w.*, k.nama_kategori 
            FROM wisata w
            JOIN kategori k ON w.id_kategori = k.id_kategori
            ORDER BY w.id_wisata
            LIMIT $limit OFFSET $offset";
    
    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $attraction = array(
                    'id_wisata' => $row['id_wisata'],
                    'nama_wisata' => $row['nama_wisata'],
                    'deskripsi' => $row['deskripsi'],
                    'alamat' => $row['alamat'],
                    'lokasi' => $row['lokasi'],
                    'gambar' => 'img/place/' . $row['gambar'],
                    'nama_kategori' => $row['nama_kategori'],
                );

                $attractions[] = $attraction;
            }
        }
        // Free the result set
        $result->free();
    } else {
        // Query failed, handle the error
        die('Error in query: ' . $conn->error);
    }

    return $attractions;
}
?>

