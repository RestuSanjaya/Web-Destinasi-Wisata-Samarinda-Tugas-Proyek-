<<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Profile</title>
</head>
<body>
  <div class="profile-logo">
  <img src="path/to/icon.png" alt="Profile Icon">
  <span><?php echo htmlspecialchars($username); ?></span>
</div>
<form action="logout.php" method="post">
  <button type="submit" name="logout">Logout</button>
</form>
<?php
session_start();
session_destroy();
header("Location: login.php");
exit;
?>

</body>
</html>

