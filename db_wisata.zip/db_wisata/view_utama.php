<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styleutama.css">
    <link rel="shortcut icon" type="image/x-icon" href="img/logo2/logokecil2.png">
    <title>Destinasi Wisata Samarinda</title>
</head>
<body>
    <div id="background-container"></div>
    <div id="content"><a href="index.php">
        <img src="img/logo2/logoetam2.png" alt="Logo" id="logo"></a>
        <div id="top-right-links">
            <a href="tentang_publik.php">About Us</a>
            <a href="kontak_kita_publik.php">Contact</a>
            <div id="menu-button">&#9776;</div>
        </div>
        <div id="menu-overlay">
            
    <div id="menu-content">
        <h1>Welcome To Samarinda Tourism</h1>
        <a href="#" id="close-button">&times;</a>
        <a href="login.php" id="login-link">Login With Account</a>
        <a href="register.php" id="register-link">Register Account</a>
        <!-- Remove the image and set background color -->
        <div id="menu-background"></div>
    </div>
</div>


    </div>
    <script src="js/utama3.js"></script>
    <script src="js/utama4.js"></script>
</body>
</html>
