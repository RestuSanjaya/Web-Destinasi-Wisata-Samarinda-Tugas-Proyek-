<?php
// Sertakan koneksi.php
include 'koneksi.php';

session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['id_user']) && !isset($_SESSION['id_admin'])) {
    // Redirect ke halaman login jika pengguna belum login
    header("Location: login.php");
    exit;
}

// Pastikan metode request adalah POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data yang dikirimkan melalui formulir
    $id_wisata = $_POST['id_wisata'];
    $komentar = $_POST['komentar'];

    // Persiapkan query untuk menyimpan komentar ke database
    $query = "INSERT INTO komentar (id_wisata, komentar) VALUES (?, ?)";

    // Persiapkan statement
    $stmt = mysqli_prepare($conn, $query);

    // Bind parameter ke statement
    mysqli_stmt_bind_param($stmt, "is", $id_wisata, $komentar);

    // Eksekusi statement
    $result = mysqli_stmt_execute($stmt);

    // Periksa apakah penyimpanan berhasil
    if ($result) {
        // Komentar berhasil disimpan, alihkan pengguna kembali ke halaman wisata dengan ID yang sesuai
        header("Location: halaman_wisata.php?id=$id_wisata");
        exit;
    } else {
        // Jika terjadi kesalahan saat menyimpan komentar
        echo "Terjadi kesalahan saat menyimpan komentar: " . mysqli_error($conn);
    }

    // Tutup statement
    mysqli_stmt_close($stmt);
}

// Tutup koneksi ke database
mysqli_close($conn);
?>
