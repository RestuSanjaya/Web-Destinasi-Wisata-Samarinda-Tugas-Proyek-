<?php
// backend_kategori_wisata.php

// Include the database connection file
include 'koneksi.php';

// backend_kategori_wisata.php

// Function to fetch tourist attractions and category name based on the provided category ID
function getAttractionsByCategory($category_id) {
    global $conn;

    $attractions = array();

    // Prepare and bind parameterized query
    $sql = "SELECT w.*, k.nama_kategori 
        FROM wisata w
        JOIN kategori k ON w.id_kategori = k.id_kategori
        WHERE k.id_kategori = ?
        ORDER BY w.id_wisata";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $category_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if there are results
    if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            $attraction = array(
                'id_wisata' => $row['id_wisata'], // Combine id_wisata with id_kategori
                'nama_wisata' => $row['nama_wisata'],
                'deskripsi' => $row['deskripsi'],
                'alamat' => $row['alamat'],
                'lokasi' => $row['lokasi'],
                'gambar' => 'img/place/' . $row['gambar'],
                'nama_kategori' => $row['nama_kategori'], // Include the category name in the result
            );

            $attractions[] = $attraction;
        }
    }

    // Close the statement
    $stmt->close();

    return $attractions;
}

?>
