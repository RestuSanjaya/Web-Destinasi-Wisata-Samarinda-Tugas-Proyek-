<?php
// Sertakan koneksi.php
include 'koneksi.php';

session_start();

// Periksa apakah pengguna sudah login
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
}
?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Edit Tempat Wisata</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <link rel="shortcut icon" type="image/x-icon" href="img/logo2/logokecil2.png">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/gijgo.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style6.css">
    <link rel="stylesheet" href="css/style3.css">
    <link rel="stylesheet" href="css/style4.css">
    <link rel="stylesheet" href="css/style5.css">
    <link rel="stylesheet" href="css/stylebanner2.css">
    <!-- <link rel="stylesheet" href="css/responsive.css"> -->
</head>

<body>
    <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->

    <!-- header-start -->
    <header>
        <div class="header-area">
            <div id="sticky-header" class="main-header-area">
                <div class="container-fluid">
                    <div class="header_bottom_border">
                        <div class="row align-items-center">
                            <div class="col-xl-2 col-lg-2">
                                <div class="logo">
                                    <a href="view_admin.php">
                                        <img src="img/logo2/logoetam2.png" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="main-menu d-none d-lg-block">
                                    <nav>
                                        <ul id="navigation">
                                            <li><a class="active" href="view_admin.php">Home</a></li>
                                            <li><a href="destinasi_wisata_admin.php">Destinasi</a></li>
                                            <li><a href="kategori_wisata_admin.php">Kategori Wisata <i class="ti-angle-down"></i></a>
                                                <ul class="submenu">
                                                    <?php
                                                    include 'backendkategori.php';
                                                    // Fetch categories from the database
                                                    $categories = getCategories();
                                                    // Counter untuk menghitung jumlah kategori yang sudah ditampilkan
                                                    $categoryCount = 0;
                                                    // Loop through the categories and generate menu items, stopping after 6 categories
                                                    foreach ($categories as $category) {
                                                    // Check if the category count has reached 6
                                                        if ($categoryCount >= 6) {
                                                        break; // Keluar dari loop jika sudah mencapai 6 kategori
                                                    }
                                                    // Tambahkan kategori ke dalam elemen <li>
                                                    echo '<li><a href="halaman_kategori_admin.php?id_kategori=' . $category['id_kategori'] . '">' . $category['nama_kategori'] . '</a></li>';
                                                    // Tingkatkan hitungan kategori
                                                    $categoryCount++;
                                                }
                                            ?>
                                            <li><center><a href="kategori_wisata_admin.php">- View All -</a></center></li>
                                        </ul>
                                    </li>
                                    <li><a class="" href="tentang_admin.php">About</a></li>
                                    <li><a href="kontak_kita_admin.php">Contact</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <form action="search_admin.php" method="POST">
                        <input type="text" name="search_query" placeholder="Cari Tempat Wisata...">
                        <a href="#">
                            <button type="submit">
                                <i class="fa fa-search">Search</i>
                            </a>
                        </button>
                    </form>
                    <div class="profile-logo">
                        <a class="logout-link">
                            <button class="logo-button">
                                <img src="img/profile2/user.png" alt="User Logo">
                            </button>
                        </a>
                        <div class="dropdown">
                            <div class="dropdown-content">
                                <?php
                                // Tampilkan username jika sudah diset
                                if (isset($username)) {
                                    echo "<p>Halo, <strong>" . htmlspecialchars($username) . "</strong> </p>";
                                }
                            ?>
                            <a href="logout.php" class="logout-link">
                                <div class="logout-button">
                                    <img src="img/profile2/logout.png" alt="Logout Logo">Logout</div></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</header>

<?php
include 'koneksi.php';

// Ambil ID Kategori dari parameter URL
$id_wisata = $_GET['id'];

// Pastikan ID wisata valid
if (!is_numeric($id_wisata)) {
    // Redirect ke halaman view_admin.php jika ID wisata tidak valid
    header("Location: view_admin.php");
    exit();
}

// Pesan sukses default kosong
$success_message = '';

// Query untuk mendapatkan data wisata berdasarkan ID
$sql = "SELECT * FROM wisata WHERE id_wisata = $id_wisata";
$result = mysqli_query($conn, $sql);

// Periksa apakah query berhasil dieksekusi
if (!$result) {
    // Tampilkan pesan kesalahan SQL
    echo "Error: " . mysqli_error($conn);
    exit();
}

// Periksa apakah data ditemukan
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
} else {
    // Redirect ke halaman view_admin.php jika data tidak ditemukan
    header("Location: more-places-admin.php");
    exit();
}

// Proses update data jika tombol submit ditekan
if (isset($_POST['submit'])) {
    // Ambil data dari formulir edit
    $nama_wisata = $_POST['nama_wisata'];
    $alamat = $_POST['alamat'];
    $deskripsi = $_POST['deskripsi'];
    $info = $_POST['info'];
    $folder_gambar = $_POST['folder_gambar'];

    // Inisialisasi variabel gambar
    $gambar = $gambar2 = $gambar3 = $gambar4 = $gambar5 = $gambar6 = $gambar7 = $gambar8 = $gambar9 = '';

    // Query UPDATE dengan sintaks yang benar
    if (!empty($_FILES['gambar']['name'])) {
        $gambar = $_FILES['gambar']['name'];
        $target_dir = "img/place/";
        $target_file = $target_dir . basename($_FILES["gambar"]["name"]);
        move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file);
    } else {
        $gambar = $row['gambar'];
    }

    if (!empty($_FILES['gambar2']['name'])) {
        $gambar2 = $_FILES['gambar2']['name'];
        $target_dir = "img/place/" . $folder_gambar . "/";
        $target_file = $target_dir . basename($_FILES["gambar2"]["name"]);
        move_uploaded_file($_FILES["gambar2"]["tmp_name"], $target_file);
    } else {
        $gambar2 = $row['gambar2'];
    }

    if (!empty($_FILES['gambar3']['name'])) {
        $gambar3 = $_FILES['gambar3']['name'];
        $target_dir = "img/place/" . $folder_gambar . "/";
        $target_file = $target_dir . basename($_FILES["gambar3"]["name"]);
        move_uploaded_file($_FILES["gambar3"]["tmp_name"], $target_file);
    } else {
        $gambar3 = $row['gambar3'];
    }

    if (!empty($_FILES['gambar4']['name'])) {
        $gambar4 = $_FILES['gambar4']['name'];
        $target_dir = "img/place/" . $folder_gambar . "/";
        $target_file = $target_dir . basename($_FILES["gambar4"]["name"]);
        move_uploaded_file($_FILES["gambar4"]["tmp_name"], $target_file);
    } else {
        $gambar4 = $row['gambar4'];
    }

    if (!empty($_FILES['gambar5']['name'])) {
        $gambar5 = $_FILES['gambar5']['name'];
        $target_dir = "img/place/" . $folder_gambar . "/";
        $target_file = $target_dir . basename($_FILES["gambar5"]["name"]);
        move_uploaded_file($_FILES["gambar5"]["tmp_name"], $target_file);
    } else {
        $gambar5 = $row['gambar5'];
    }

    if (!empty($_FILES['gambar6']['name'])) {
        $gambar6 = $_FILES['gambar6']['name'];
        $target_dir = "img/place/" . $folder_gambar . "/";
        $target_file = $target_dir . basename($_FILES["gambar6"]["name"]);
        move_uploaded_file($_FILES["gambar6"]["tmp_name"], $target_file);
    } else {
        $gambar6 = $row['gambar6'];
    }

    if (!empty($_FILES['gambar7']['name'])) {
        $gambar7 = $_FILES['gambar7']['name'];
        $target_dir = "img/place/" . $folder_gambar . "/";
        $target_file = $target_dir . basename($_FILES["gambar7"]["name"]);
        move_uploaded_file($_FILES["gambar7"]["tmp_name"], $target_file);
    } else {
        $gambar7 = $row['gambar7'];
    }

    if (!empty($_FILES['gambar8']['name'])) {
        $gambar8 = $_FILES['gambar8']['name'];
        $target_dir = "img/place/" . $folder_gambar . "/";
        $target_file = $target_dir . basename($_FILES["gambar8"]["name"]);
        move_uploaded_file($_FILES["gambar8"]["tmp_name"], $target_file);
    } else {
        $gambar8 = $row['gambar8'];
    }

    if (!empty($_FILES['gambar9']['name'])) {
        $gambar9 = $_FILES['gambar9']['name'];
        $target_dir = "img/place/" . $folder_gambar . "/";
        $target_file = $target_dir . basename($_FILES["gambar9"]["name"]);
        move_uploaded_file($_FILES["gambar9"]["tmp_name"], $target_file);
    } else {
        $gambar9 = $row['gambar9'];
    }

    // Query untuk update data wisata
    $update_sql = "UPDATE wisata SET 
                    nama_wisata = '$nama_wisata',
                    alamat = '$alamat',
                    gambar = '$gambar',
                    deskripsi = '$deskripsi',
                    info = '$info',
                    folder_gambar = '$folder_gambar',
                    gambar2 = '$gambar2',
                    gambar3 = '$gambar3',
                    gambar4 = '$gambar4',
                    gambar5 = '$gambar5',
                    gambar6 = '$gambar6',
                    gambar7 = '$gambar7',
                    gambar8 = '$gambar8',
                    gambar9 = '$gambar9'
                    WHERE id_wisata = $id_wisata";
    
    // Eksekusi query update
    if (mysqli_query($conn, $update_sql)) {
        // Tampilkan pesan sukses
        $success_message = "Anda berhasil mengubah tempat wisata, silahkan cek <a href='more-places-admin.php' style='color: blue; text-decoration: none;'><span style='text-decoration: underline;'>Di Sini</span></a>";
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>

<div class="popular_destination_area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section_title text-center mb_70">
                    <h3 class="teksslider_a">Ubah Tempat Wisata</h3>
                </div>
            </div>
        </div>
        <!-- Tampilkan pesan sukses jika ada -->
        <div class="col-md-12">
            <?php if (!empty($success_message)) : ?>
                <div class="alert alert-success" role="alert">
                    <?= $success_message ?>
                </div>
            <?php endif; ?>
        </div>
        <form id="category-form" action="" method="POST" enctype="multipart/form-data" class="form">
            <div class="form-left">
                <div class="form-group">
                    <label for="nama_wisata">Nama Wisata:</label>
                    <input id="nama_wisata" type="text" name="nama_wisata" value="<?= $row['nama_wisata']; ?>" class="form-control" placeholder="Masukkan Nama Wisata" required>
                </div>

                <div class="form-group">
                    <label for="alamat">Alamat Wisata:</label>
                    <input id="alamat" type="text" name="alamat" class="form-control" placeholder="Masukkan Alamat Wisata" value="<?= $row['alamat']; ?>" required>

                </div>

                <div class="form-group">
                    <label for="id_kategori">Kategori Wisata:</label>
                    <select name="id_kategori" required>
    <option value="">Pilih Kategori</option>
    <?php
    // Include koneksi.php untuk menginisialisasi koneksi
    include 'koneksi.php';

    // Query untuk mendapatkan kategori dari tabel kategori
    $kategori_query = "SELECT id_kategori, nama_kategori FROM kategori";
    $kategori_result = mysqli_query($conn, $kategori_query);

    // Periksa apakah query berhasil dijalankan
    if ($kategori_result && mysqli_num_rows($kategori_result) > 0) {
        // Tampilkan opsi kategori
        while ($kategori_row = mysqli_fetch_assoc($kategori_result)) {
            // Tentukan apakah kategori saat ini dipilih atau tidak
            $selected = ($kategori_row['id_kategori'] == $row['id_kategori']) ? 'selected' : '';
            echo '<option value="' . $kategori_row['id_kategori'] . '" ' . $selected . '>' . $kategori_row['nama_kategori'] . '</option>';
        }
    } else {
        // Tampilkan pesan jika tidak ada kategori yang tersedia
        echo '<option disabled selected>Tidak ada kategori tersedia</option>';
    }
    ?>
</select>
                </div>

                <div class="form-group">
                    <label for="info">Tentang Wisata:</label>
                    <textarea id="info" name="info" class="form-control" placeholder="Masukkan Tentang Wisata"><?= $row['info']; ?></textarea>
                </div>

                <div class="form-group">
                    <label for="folder_gambar">Nama Folder Gambar:</label>
                    <input id="folder_gambar" type="text" name="folder_gambar" value="<?= $row['folder_gambar']; ?>" class="form-control" placeholder="Masukkan Nama Folder Gambar">
                </div>

                <div class="form-group">
                    <label for="deskripsi">Keterangan Singkat:</label>
                    <textarea id="deskripsi" name="deskripsi" class="form-control" placeholder="Masukkan Keterangan Singkat" required><?= $row['deskripsi']; ?></textarea>
                </div>
            </div>

            <div class="form-right">
                <div class="form-group">
                    <label for="gambar">Gambar Utama:</label>
                    <input id="gambar" type="file" name="gambar" class="form-control-file" accept="">
                </div>

            <div class="form-group">
            <label for="gambar2">Gambar 1:</label>
            <input id="gambar2" type="file" name="gambar2" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar3">Gambar 2:</label>
            <input id="gambar3" type="file" name="gambar3" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar4">Gambar 3:</label>
            <input id="gambar4" type="file" name="gambar4" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar5">Gambar 4:</label>
            <input id="gambar5" type="file" name="gambar5" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar6">Gambar 5:</label>
            <input id="gambar6" type="file" name="gambar6" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar7">Gambar 6:</label>
            <input id="gambar7" type="file" name="gambar7" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar8">Gambar 7:</label>
            <input id="gambar8" type="file" name="gambar8" class="form-control-file" accept="">
        </div>

        <div class="form-group">
            <label for="gambar9">Gambar 8:</label>
            <input id="gambar9" type="file" name="gambar9" class="form-control-file" accept="">
        </div>

            </div>

            <div class="form-group">
                <button id="submit-btn" type="submit" name="submit" class="btn btn-primary">Ubah Wisata</button>
            </div>
        </form>
    </div>
</div>

<footer class="footer">    
        <div class="copy-right_text">
            <div class="container">
                <div class="footer_border"></div>
                <div class="row">
                    <div class="col-xl-12">
                        <p class="copy_right text-center">
                           
 &copy;<script>document.write(new Date().getFullYear());</script> This Website is Samarinda Tourism 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>


  <!-- Modal -->
  <div class="modal fade custom_search_pop" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="serch_form">
            <input type="text" placeholder="Search" >
            <button type="submit">search</button>
        </div>
      </div>
    </div>
  </div>
    <!-- link that opens popup -->
<!--     
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://static.codepen.io/assets/common/stopExecutionOnTimeout-de7e2ef6bfefd24b79a3f68b414b87b8db5b08439cac3f1012092b2290c719cd.js"></script>

    <script src=" https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"> </script> -->
    <!-- JS here -->
    <script src="js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/ajax-form.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/scrollIt.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/nice-select.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/gijgo.min.js"></script>
    <script src="js/slick.min.js"></script>
   

    
    <!--contact js-->
    <script src="js/contact.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <script src="js/jquery.form.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/mail-script.js"></script>


    <script src="js/main.js"></script>
    <script>
        $('#datepicker').datepicker({
            iconsLibrary: 'fontawesome',
            icons: {
             rightIcon: '<span class="fa fa-caret-down"></span>'
         }
        });
    </script>
</body>

</html>
