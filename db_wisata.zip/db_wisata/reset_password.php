<?php
include 'koneksi.php'; // Include your database connection file

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from the form
    $reset_code = $_POST['verification_code'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate the reset code
    $query = "SELECT * FROM user WHERE reset_code = ?"; // Removed reset_code_used condition
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        die("Error in query: " . $conn->error); // Display an error message
    }

    $stmt->bind_param('s', $reset_code);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        // Validate passwords
        if ($new_password === $confirm_password) {
            // Hash the new password before updating the database
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Update the user's password
            $update_query = "UPDATE user SET password = ? WHERE id_user = ?";
            $update_stmt = $conn->prepare($update_query);

            if (!$update_stmt) {
                die("Error in query: " . $conn->error); // Display an error message
            }

            $update_stmt->bind_param('si', $hashed_password, $user['id_user']);

            $update_password_result = $update_stmt->execute();

            if ($update_password_result) {
                $success_message = "Password has been successfully reset. You can now <a href='login.php'>login</a> with your new password.";
            } else {
                $error_message = "Failed to reset password. Please try again.";
            }
        } else {
            $error_message = "Passwords do not match.";
        }
    } else {
        $error_message = "Incorrect verification code.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="shortcut icon" type="image/x-icon" href="img/logo2/logokecil2.png">
    <!-- Tambahkan stylesheet sesuai kebutuhan Anda -->
    <style>
    /* Tambahkan stylesheet sesuai kebutuhan Anda */
    @import url('css/stylelogin.css');
    @import url('css/styleutama.css');
    </style>
</head>
<body class="">
    <div id="background-container"></div>
    <div id="content"><a href="index.php">
        <img src="img/logo2/logoetam2.png" alt="Logo" id="logo"></a>
        <div id="top-right-links">
            <a href="tentang.php">About Us</a>
            <a href="kontak_kita.php">Contact</a>
        </div>
    <div class="grid">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="form login">
            <div class="judul"><a href="reset_password.php" class="b">Reset Password</a></div>

            <?php
            // Display success or error message
            if (!empty($success_message)) {
                echo '<p style="color: green; text-align: center;">' . $success_message . '</p>';
            } elseif (!empty($error_message)) {
                echo '<p style="color: red; text-align: center;">' . $error_message . '</p>';
            }
            ?>

            <div class="form__field">
        <label for="verification_code">
            <svg class="icon">
                <use xlink:href="#icon-verification-code"></use>
            </svg>
            <span class="hidden">Verifikasi Kode</span>
        </label>
        <input type="text" id="verification_code" name="verification_code" placeholder="Verification Code From Email" required>
    </div>
    <div class="form__field">
        <label for="new_password">
            <svg class="icon">
                <use xlink:href="#icon-lock"></use>
            </svg>
            <span class="hidden">New Password</span>
        </label>
        <input type="password" id="new_password" name="new_password" placeholder="New Password" required>
    </div>
    <div class="form__field">
        <label for="confirm_password">
            <svg class="icon">
                <use xlink:href="#icon-lock"></use>
            </svg>
            <span class="hidden">Confirm Password</span>
        </label>
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
    </div>
    <div class="form__field">
        <input type="submit" value="Reset Password" name="reset_password">
    </div><hr class="divider2"><p class="text--center">Remember your password? <a href="login.php" class="blue-link">Sign in</a><svg class="icon">
                    <use xlink:href="#icon-arrow-right"></use>
                </svg>
    </form>

    <!-- Simbol SVG -->
    <svg xmlns="http://www.w3.org/2000/svg" class="icons" style="display: none;">
        <symbol id="icon-arrow-right" viewBox="0 0 1792 1792">
            <path
                d="M1600 960q0 54-37 91l-651 651q-39 37-91 37-51 0-90-37l-75-75q-38-38-38-91t38-91l293-293H245q-52 0-84.5-37.5T128 1024V896q0-53 32.5-90.5T245 768h704L656 474q-38-36-38-90t38-90l75-75q38-38 90-38 53 0 91 38l651 651q37 35 37 90z" />
        </symbol>
        <symbol id="icon-lock" viewBox="0 0 1792 1792">
            <path d="M640 768h512V576q0-106-75-181t-181-75-181 75-75 181v192zm832 96v576q0 40-28 68t-68 28H416q-40 0-68-28t-28-68V864q0-40 28-68t68-28h32V576q0-184 132-316t316-132 316 132 132 316v192h32q40 0 68 28t28 68z" />
        </symbol>
        <symbol id="icon-verification-code" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15h2v2h-2zm0-10h2v6h-2zm0 8h2v2h-2z"/>
        </symbol>
    </svg>
    <script src="js/utama3.js"></script>
    <script src="js/utama4.js"></script>
</body>
</html>
