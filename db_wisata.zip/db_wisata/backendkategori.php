<?php
// backend_kategori.php

// Include the database connection file
include 'koneksi.php';

// Function to fetch category data
function getCategories() {
    global $conn;

    $categories = array();

    // Sample query to fetch category data
    $sql = "SELECT * FROM kategori";
    $result = $conn->query($sql);

    // Check if there are results
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $category = array(
                'id_kategori' => $row['id_kategori'],
                'nama_kategori' => $row['nama_kategori'],
                'gambar' => 'img/destination/' . $row['gambar'],
            );

            $categories[] = $category;
        }
    }

    // Close the result set
    $result->close();

    return $categories;
}
?>
