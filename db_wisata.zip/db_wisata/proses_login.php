<?php
// Backend user pengguna
include 'koneksi.php'; 

session_start();

// Define your SQL query
$sql_user = 'SELECT id_user, username, password FROM user WHERE username = ?';
$sql_admin = 'SELECT id_admin, username, password FROM admin WHERE username = ?';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    // Get input values from the form
    $username = $_POST['name'];
    $password = $_POST['password'];

    // Prepare and execute the SQL query for user
    $stmt_user = $conn->prepare($sql_user);
    if (!$stmt_user) {
        die('Error in preparing the statement: ' . $conn->error);
    }
    $stmt_user->bind_param('s', $username);
    $stmt_user->execute();
    $stmt_user->bind_result($id_user, $db_username, $db_password);
    $stmt_user->fetch();

    // Verify the password for user
    if ($db_username && password_verify($password, $db_password)) {
        // Login berhasil untuk pengguna
        $_SESSION['id_user'] = $id_user;
        $_SESSION['username'] = $db_username;
        header('Location: view_awal.php'); // Redirect to the desired page
        exit();
    }

    // Close the statement for user
    $stmt_user->close();

    // Prepare and execute the SQL query for admin
    $stmt_admin = $conn->prepare($sql_admin);
    if (!$stmt_admin) {
        die('Error in preparing the statement: ' . $conn->error);
    }
    $stmt_admin->bind_param('s', $username);
    $stmt_admin->execute();
    $stmt_admin->bind_result($id_admin, $db_username, $db_password);
    $stmt_admin->fetch();

    // Verify the password for admin
    if ($db_username && $password === $db_password) {
        // Login berhasil untuk admin
        $_SESSION['id_admin'] = $id_admin;
        $_SESSION['username'] = $db_username;
        header('Location: view_admin.php'); // Redirect to the desired page
        exit();
    }

    // Close the statement for admin
    $stmt_admin->close();

    // Jika username atau password tidak cocok untuk kedua peran
    $error_message = 'Username atau Password Salah';
}
?>
