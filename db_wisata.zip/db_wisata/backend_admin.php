<?php
// backend.php

// Include the database connection file
include 'koneksi.php';

// Function to fetch tourist attractions
function getAttractions() {
    global $conn;

    $attractions = array();

    // Sample query to fetch tourist attractions ordered by id_wisata
    $sql = "SELECT w.*, k.nama_kategori 
            FROM wisata w
            JOIN kategori k ON w.id_kategori = k.id_kategori
            ORDER BY w.id_wisata";

    // Execute the query
    $result = $conn->query($sql);

    // Check if the query was successful
    if ($result) {
        // Check if there are results
        if ($result->num_rows > 0) {
            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                $attraction = array(
                    'id_wisata' => $row['id_wisata'],
                    'nama_wisata' => $row['nama_wisata'],
                    'deskripsi' => $row['deskripsi'],
                    'alamat' => $row['alamat'],
                    'lokasi' => $row['lokasi'],
                    'gambar' => 'img/place/' . $row['gambar'],
                    'nama_kategori' => $row['nama_kategori'],
                    'id_kategori' => $row['id_kategori'],
                );

                $attractions[] = $attraction;
            }
        }

        // Free the result set
        $result->free();
    } else {
        // Query failed, handle the error (you can customize this based on your needs)
        die('Error in query: ' . $conn->error);
    }

    // Close connection
    $conn->close();

    return $attractions;
}
?>