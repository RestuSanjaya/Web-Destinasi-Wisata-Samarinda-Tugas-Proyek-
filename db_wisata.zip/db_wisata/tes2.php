<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Send Email</title>
</head>
<body>
	<form class="" action="send.php" method="post">
		Email <input type="email" name="email" value="">
		Subject <input type="text" name="subject" value="">
		Message <input type="text" name="message" value="">
		<button type="submit" name="send">Send</button>
	</form>

</body>
</html>