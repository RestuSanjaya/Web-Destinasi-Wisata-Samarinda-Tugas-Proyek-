<!--
=========================================================
* Argon Dashboard 2 - v2.0.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard
* Copyright 2022 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://www.creative-tim.com/license)
* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->

<?php
session_start();
if (empty($_SESSION['username'])) { ?>
    <script>
        alert('Silahkan login dulu!')
        window.location.assign('indeks.php');
    </script>

<?php } ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="Assets_Tamplate/img/Pesawat.png">
    <link rel="icon" type="image/png" href="Assets_Tamplate/img/Pesawat.png">
    <title>
        Input Catatan Perjalanan
    </title>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <!-- Nucleo Icons -->
    <link href="Assets_Tamplate/assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="Assets_Tamplate/assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="Assets_Tamplate/assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- CSS Files -->
    <link id="pagestyle" href="Assets_Tamplate/assets/css/argon-dashboard.css?v=2.0.0" rel="stylesheet" />

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
    <!-- Make sure you put this AFTER Leaflet's CSS -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

</head>

<body class="g-sidenav-show   bg-gray-100">
    <div class="min-height-300 bg-primary position-absolute w-100"></div>
    <aside class="sidenav bg-white navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-4 " id="sidenav-main">
        <div class="sidenav-header">
            <i class="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
            <a class="navbar-brand m-0" href=" # ">
                <span class="ms-1 font-weight-bold">
                    <center> Aplikasi TravelRecord</center>
                </span>
            </a>
        </div>
        <hr class="horizontal dark mt-0">
        <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link " href="user.php">
                        <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="ni ni-tv-2 text-primary text-sm opacity-10"></i>
                        </div>
                        <span class="nav-link-text ms-1">Dashboard</span>
                    </a>
                </li>
                <li class="nav-item mt-3">
                    <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">Laporan dan Input Data</h6>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="Catatan.php">
                        <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="ni ni-calendar-grid-58 text-warning text-sm opacity-10"></i>
                        </div>
                        <span class="nav-link-text ms-1">Catatan Perjalanan</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active " href="input_catatan.php">
                        <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="ni ni-world-2 text-danger text-sm opacity-10"></i>
                        </div>
                        <span class="nav-link-text ms-1">Input Catatan Perjalanan</span>
                    </a>
                </li>
                <li class="nav-item mt-3">
                    <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">Keluar Aplikasi</h6>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="logout.php">
                        <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="ni ni-collection text-info text-sm opacity-10"></i>
                        </div>
                        <span class="nav-link-text ms-1">Keluar</span>
                    </a>
                </li>
            </ul>
        </div>
    </aside>
    <main class="main-content position-relative border-radius-lg ">
        <!-- Navbar -->
        <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl " id="navbarBlur" data-scroll="false">
            <div class="container-fluid py-1 px-3">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
                        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Pages</a></li>
                        <li class="breadcrumb-item text-sm text-white active" aria-current="page">Input Catatan Perjalanan</li>
                    </ol>
                    <h6 class="font-weight-bolder text-white mb-0">Input Catatan Perjalanan</h6>
                </nav>
                <li class="nav-item px-3 d-flex align-items-center">
                    <a href="javascript:;" class="nav-link text-white p-0">
                        <i class="fa fa-cog fixed-plugin-button-nav cursor-pointer"></i>
                    </a>
                </li>
            </div>
            </div>
        </nav>
        <!-- End Navbar -->
        <div class="container-fluid py-4">
            <div class="row">
                <div class="col-12">
                    <div class="card mb-4">
                        <div class="card-header pb-0">
                            <h6>Input Data</h6>
                        </div>
                        <div class="card-body">
                            <form action="simpan_input.php" method="post">
                                    <input type="hidden" name="id_user" >
                                <div class="form-group">
                                    <label>Pilih Tanggal</label>
                                    <input name="tanggal" type="date" required class="form-control" placeholder="Masukan Tanggal">
                                </div>
                                <div class="form-group">
                                    <label>Pilih Jam</label>
                                    <input name="waktu" type="time" required class="form-control" placeholder="Masukan Jam">
                                </div>
                                <div class="form-group">
                                    <label>Suhu Tempat</label>
                                    <input name="suhu" type="number" required class="form-control" placeholder="Masukan Suhu Tempat">
                                </div>

                                <div class="form-group">
                                    <label>Lokasi</label>
                                    <input type="hidden" name="latitude">
                                    <input type="hidden" name="longitude">
                                    <input id="lokasi" type="text" class="form-control" placeholder="Masukkan lokasi">
                                </div>

                                <style>
                                    #map {
                                        height: 500px;
                                    }
                                </style>

                                <div id="map"></div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> SIMPAN </button>
                                    <button type="reset" class="btn btn-warning"><i class="fa fa-trash"></i> KOSONGKAN </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer pt-3  ">
            <div class="container-fluid">
                <div class="row align-items-center justify-content-lg-between">
                    <div class="col-lg-6 mb-lg-0 mb-4">
                        <div class="copyright text-center text-sm text-muted text-lg-start">

                            © <script>
                                document.write(new Date().getFullYear())
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        </div>
    </main>
    <div class="fixed-plugin">
        <a class="fixed-plugin-button text-dark position-fixed px-3 py-2">
            <i class="fa fa-cog py-2"> </i>
        </a>
        <div class="card shadow-lg">
            <div class="card-header pb-0 pt-3 ">
                <div class="float-start">
                    <h5 class="mt-3 mb-0">Konfigurasi Tema</h5>
                </div>
                <div class="float-end mt-4">
                    <button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
                        <i class="fa fa-close"></i>
                    </button>
                </div>
                <!-- End Toggle Button -->
            </div>
            <hr class="horizontal dark my-1">
            <div class="card-body pt-sm-3 pt-0 overflow-auto">
                <!-- Sidebar Backgrounds -->
                <div>
                    <h6 class="mb-0">Warna Sidebar</h6>
                </div>
                <a href="javascript:void(0)" class="switch-trigger background-color">
                    <div class="badge-colors my-2 text-start">
                        <span class="badge filter bg-gradient-primary active" data-color="primary" onclick="sidebarColor(this)"></span>
                        <span class="badge filter bg-gradient-dark" data-color="dark" onclick="sidebarColor(this)"></span>
                        <span class="badge filter bg-gradient-info" data-color="info" onclick="sidebarColor(this)"></span>
                        <span class="badge filter bg-gradient-success" data-color="success" onclick="sidebarColor(this)"></span>
                        <span class="badge filter bg-gradient-warning" data-color="warning" onclick="sidebarColor(this)"></span>
                        <span class="badge filter bg-gradient-danger" data-color="danger" onclick="sidebarColor(this)"></span>
                    </div>
                </a>
                <!-- Sidenav Type -->
                <div class="mt-3">
                    <h6 class="mb-0">Sidenav Type</h6>
                    <p class="text-sm">Ada 2 Macam Pilihan</p>
                </div>
                <div class="d-flex">
                    <button class="btn bg-gradient-primary w-100 px-3 mb-2 active me-2" data-class="bg-white" onclick="sidebarType(this)">White</button>
                    <button class="btn bg-gradient-primary w-100 px-3 mb-2" data-class="bg-default" onclick="sidebarType(this)">Dark</button>
                </div>
                <p class="text-sm d-xl-none d-block mt-2">Kamu Bisa Mengubah Sesuai Keinginan</p>
                <!-- Navbar Fixed -->

                <hr class="horizontal dark my-sm-4">
                <div class="mt-2 mb-5 d-flex">
                </div>
            </div>
        </div>
    </div>
    <!--   Core JS Files   -->
    <script src="Assets_Tamplate/assets/js/core/popper.min.js"></script>
    <script src="Assets_Tamplate/assets/js/core/bootstrap.min.js"></script>
    <script src="Assets_Tamplate/assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="Assets_Tamplate/assets/js/plugins/smooth-scrollbar.min.js"></script>
    <script src="Assets_Tamplate/assets/js/plugins/chartjs.min.js"></script>
    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="Assets_Tamplate/assets/js/argon-dashboard.min.js?v=2.0.0"></script>

    <script>
        const latitdeInput = document.querySelector("input[name='latitude']")
        const longitudeInput = document.querySelector("input[name='longitude']")

        function setLocationToMarker(marker) {
            latitdeInput.value = marker._latlng.lat
            longitudeInput.value = marker._latlng.lng
        }

        const map = L.map('map')
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        }).addTo(map);


        var geolocationOptions = {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0,
        };

        let marker;
        navigator.geolocation.getCurrentPosition((pos) => {
            map.setView([pos.coords.latitude, pos.coords.longitude], 17);
            marker = L.marker([pos.coords.latitude, pos.coords.longitude]).addTo(map);
            setLocationToMarker(marker)
        }, () => {
            alert("Cannot get current location.")
        }, geolocationOptions);


        map.on('click', (e) => {
            marker.remove()

            const lat = e.latlng.lat
            const lng = e.latlng.lng
            marker = L.marker([lat, lng]).addTo(map);
            setLocationToMarker(marker)
        });
    </script>

    <script>
        const inputLocation = document.getElementById("lokasi")

        // Debounce function from: https://stackoverflow.com/q/24004791/1814486
        const debounceInput = (func, wait, immediate) => {
            let timeout

            return function() {
                const context = this,
                    args = arguments
                const later = function() {
                    timeout = null
                    if (!immediate) func.apply(context, args)
                }

                const callNow = immediate && !timeout
                clearTimeout(timeout)
                timeout = setTimeout(later, wait)
                if (callNow) func.apply(context, args)
            }
        }


        inputLocation.addEventListener("input",
            debounceInput(() => {
                console.log(inputLocation.value)
                fetch(`${location.protocol}//nominatim.openstreetmap.org/search?format=json&q=${inputLocation.value}`)
                    .then((res) => res.json())
                    .then((data) => {

                        const lat = data[0].lat
                        const lng = data[0].lon

                        marker.remove()
                        marker = L.marker([lat, lng]).addTo(map);
                        setLocationToMarker(marker)

                        map.setView([lat, lng], 17);
                    })
            }, 500)
        )
    </script>

    <!-- Penempatan Kode JavaScript di Bagian Akhir Halaman -->
<script>
    // Function to update location input with the name of the location
    function updateLocationName(latitude, longitude) {
        fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`)
            .then(response => response.json())
            .then(data => {
                const locationName = data.display_name; // Extract location name from response
                document.getElementById('lokasi').value = locationName; // Update location input with location name
            })
            .catch(error => {
                console.error('Error fetching location data:', error);
            });
    }

    // Call the function to update location name when page loads
    window.onload = function() {
        // Assuming latitude and longitude are already available in your form
        const latitude = parseFloat(document.querySelector("input[name='latitude']").value);
        const longitude = parseFloat(document.querySelector("input[name='longitude']").value);
        
        // Update location name input
        updateLocationName(latitude, longitude);
    };
</script>
</body>
</html>


</body>

</html>
