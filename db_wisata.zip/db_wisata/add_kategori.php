<?php
// Sertakan koneksi.php
include 'koneksi.php';

session_start();

// Periksa apakah pengguna sudah login
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
}
?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Tambah Kategori Wisata</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <link rel="shortcut icon" type="image/x-icon" href="img/logo2/logokecil2.png">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/gijgo.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style6.css">
    <link rel="stylesheet" href="css/style3.css">
    <link rel="stylesheet" href="css/style4.css">
    <link rel="stylesheet" href="css/style5.css">
    <link rel="stylesheet" href="css/stylebanner2.css">
    <!-- <link rel="stylesheet" href="css/responsive.css"> -->
</head>

<body>
    <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->

    <!-- header-start -->
    <header>
        <div class="header-area">
            <div id="sticky-header" class="main-header-area">
                <div class="container-fluid">
                    <div class="header_bottom_border">
                        <div class="row align-items-center">
                            <div class="col-xl-2 col-lg-2">
                                <div class="logo">
                                    <a href="view_admin.php">
                                        <img src="img/logo2/logoetam2.png" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="main-menu d-none d-lg-block">
                                    <nav>
                                        <ul id="navigation">
                                            <li><a class="active" href="view_admin.php">Home</a></li>
                                            <li><a href="destinasi_wisata_admin.php">Destinasi</a></li>
                                            <li><a href="kategori_wisata_admin.php">Kategori Wisata <i class="ti-angle-down"></i></a>
                                                <ul class="submenu">
                                                    <?php
                                                    include 'backendkategori.php';
                                                    // Fetch categories from the database
                                                    $categories = getCategories();
                                                    // Counter untuk menghitung jumlah kategori yang sudah ditampilkan
                                                    $categoryCount = 0;
                                                    // Loop through the categories and generate menu items, stopping after 6 categories
                                                    foreach ($categories as $category) {
                                                    // Check if the category count has reached 6
                                                        if ($categoryCount >= 6) {
                                                        break; // Keluar dari loop jika sudah mencapai 6 kategori
                                                    }
                                                    // Tambahkan kategori ke dalam elemen <li>
                                                    echo '<li><a href="halaman_kategori_admin.php?id_kategori=' . $category['id_kategori'] . '">' . $category['nama_kategori'] . '</a></li>';
                                                    // Tingkatkan hitungan kategori
                                                    $categoryCount++;
                                                }
                                            ?>
                                            <li><center><a href="kategori_wisata_admin.php">- View All -</a></center></li>
                                        </ul>
                                    </li>
                                    <li><a class="" href="tentang_admin.php">About</a></li>
                                    <li><a href="kontak_kita_admin.php">Contact</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <form action="search_admin.php" method="POST">
                        <input type="text" name="search_query" placeholder="Cari Tempat Wisata...">
                        <a href="#">
                            <button type="submit">
                                <i class="fa fa-search">Search</i>
                            </a>
                        </button>
                    </form>
                    <div class="profile-logo">
                        <a class="logout-link">
                            <button class="logo-button">
                                <img src="img/profile2/user.png" alt="User Logo">
                            </button>
                        </a>
                        <div class="dropdown">
                            <div class="dropdown-content">
                                <?php
                                // Tampilkan username jika sudah diset
                                if (isset($username)) {
                                    echo "<p>Halo, <strong>" . htmlspecialchars($username) . "</strong> </p>";
                                }
                            ?>
                            <a href="logout.php" class="logout-link">
                                <div class="logout-button">
                                    <img src="img/profile2/logout.png" alt="Logout Logo">Logout</div></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</header>


<?php
// Include the database connection file
include 'koneksi.php';

// Fungsi untuk menambahkan kategori
function addCategory($nama_kategori, $gambar) {
    global $conn;

    // Sanitize input data
    $nama_kategori = mysqli_real_escape_string($conn, $nama_kategori);

    // Query SQL untuk memeriksa apakah kategori sudah ada dalam database
    $check_sql = "SELECT * FROM kategori WHERE nama_kategori = '$nama_kategori'";
    $check_result = mysqli_query($conn, $check_sql);

    // Jika kategori sudah ada, kembalikan pesan
    if (mysqli_num_rows($check_result) > 0) {
        return "Sepertinya Kategori Wisata ini Sudah Ditambahkan.";
    }

    // Jika kategori belum ada, lanjutkan dengan menambahkannya
    $sql = "INSERT INTO kategori (nama_kategori, gambar) VALUES (?, ?)";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", $nama_kategori, $gambar);
        $result = mysqli_stmt_execute($stmt);

        // Cek apakah kategori berhasil ditambahkan
        if ($result) {
            return true; // Berhasil menambahkan kategori
        } else {
            echo 'Error adding the category: ' . mysqli_error($conn);
            return false; // Gagal menambahkan kategori
        }

        mysqli_stmt_close($stmt);
    } else {
        echo 'Error in preparing the statement: ' . mysqli_error($conn);
        return false; // Gagal menambahkan kategori
    }
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process the form data
    $nama_kategori = $_POST['nama_kategori'];

    // Image upload handling
    $uploadDir = ''; // Tentukan folder upload yang tepat

    // Jika ada file gambar yang diunggah, proses upload
    if ($_FILES['gambar']['name']) {
        $gambar = $_FILES['gambar']['name'];
        $target_dir = "img/destination/";
        $target_file = $target_dir . basename($_FILES["gambar"]["name"]);
        
        // Periksa apakah file yang diunggah adalah file gambar yang valid
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        $validExtensions = array("jpg", "jpeg", "png", "gif");
        
        if (in_array($imageFileType, $validExtensions)) {
            if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
                // File berhasil diunggah
            } else {
                echo 'Error uploading the file.';
                exit; // Stop script execution if file upload fails
            }
        } else {
            echo 'Invalid file type. Please upload a valid image.';
            exit; // Stop script execution for an invalid file type
        }
    } else {
        // Jika tidak ada gambar yang diunggah, gunakan gambar yang sudah ada
        $gambar = ''; // Tentukan gambar default jika tidak ada gambar yang diunggah
    }

    // Call the function to add a new category
    $result = addCategory($nama_kategori, $gambar);

    // Process the result of adding category
    if ($result === true) {
        // Kategori berhasil ditambahkan
        $result_message = "Kategori Wisata berhasil ditambahkan";
    } elseif ($result === false) {
        // Terjadi kesalahan saat menambahkan kategori
        $error_message = "Terjadi kesalahan saat menambahkan kategori";
    } else {
        // Kategori sudah ada dalam database
        $duplicate_message = $result;
    }
}
?>



<div class="popular_destination_area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section_title text-center mb_70">
                    <h3 style="margin-top: 5px;" class="teksslider_a">Tambahkan Kategori Wisata</h3>
                    <?php 
                    if (isset($error_message)) {
                        echo '<p style="color: red;">' . htmlspecialchars($error_message) . '</p>';
                    } elseif (isset($result_message)) {
                        echo '<p style="color: green;">' . htmlspecialchars($result_message) . '</p>';
                        echo '<p style="color: green;">Silahkan Cek Kategori Yang Sudah Di Tambahkan <a href="kategori_wisata_admin.php"><u style="color: blue;">Di Sini.</u></a></p>';
                    } elseif (isset($duplicate_message)) {
                        echo '<div class="section_title text-center mb_70">';
                        echo '<p style="color: orange;">' . htmlspecialchars($duplicate_message) . '</p>';
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="row">
            <form id="category-form" action="add_kategori.php" method="POST" enctype="multipart/form-data">
                <label for="nama_kategori">Masukkan Nama Kategori:</label>
                <input id="input-2" type="text" name="nama_kategori" placeholder="Masukkan Nama Kategori Di Sini" required>

                <label for="gambar">Masukkan Gambar Kategori:</label>
                <input id="input-2" type="file" name="gambar" accept="" required>

                <button id="button-2" type="submit">Tambah Kategori</button>
            </form>
        </div>
    </div>
</div>

<footer class="footer">    
        <div class="copy-right_text">
            <div class="container">
                <div class="footer_border"></div>
                <div class="row">
                    <div class="col-xl-12">
                        <p class="copy_right text-center">
                           
 &copy;<script>document.write(new Date().getFullYear());</script> This Website is Samarinda Tourism 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>


  <!-- Modal -->
  <div class="modal fade custom_search_pop" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="serch_form">
            <input type="text" placeholder="Search" >
            <button type="submit">search</button>
        </div>
      </div>
    </div>
  </div>
    <!-- link that opens popup -->
<!--     
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://static.codepen.io/assets/common/stopExecutionOnTimeout-de7e2ef6bfefd24b79a3f68b414b87b8db5b08439cac3f1012092b2290c719cd.js"></script>

    <script src=" https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"> </script> -->
    <!-- JS here -->
    <script src="js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/ajax-form.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/scrollIt.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/nice-select.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/gijgo.min.js"></script>
    <script src="js/slick.min.js"></script>
   

    
    <!--contact js-->
    <script src="js/contact.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <script src="js/jquery.form.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/mail-script.js"></script>


    <script src="js/main.js"></script>
    <script>
        $('#datepicker').datepicker({
            iconsLibrary: 'fontawesome',
            icons: {
             rightIcon: '<span class="fa fa-caret-down"></span>'
         }
        });
    </script>
</body>

</html>
