<?php
// Include file koneksi.php
include 'koneksi.php';

// Inisialisasi variabel
$username_reg = $password_reg = $confirm_password_reg = $email_reg = '';
$error_message_reg = '';
// Perbarui PHP

// Cek apakah form pendaftaran sudah disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    // Ambil data dari form
    $email_reg = $_POST["email_reg"];
    $username_reg = $_POST["username_reg"];
    $password_reg = $_POST["password_reg"];
    $confirm_password_reg = $_POST["confirm_password_reg"];

    // Validasi input (Contoh: Pastikan semua field diisi, password cocok)
    if (empty($email_reg) || empty($username_reg) || empty($password_reg) || empty($confirm_password_reg)) {
        $error_message_reg = "Semua field harus diisi.";
    } elseif (!filter_var($email_reg, FILTER_VALIDATE_EMAIL)) {
        $error_message_reg = "Format email tidak valid.";
    } elseif ($password_reg != $confirm_password_reg) {
        $error_message_reg = "Konfirmasi Password Tidak Cocok.";
    } else {
        // Query untuk memeriksa apakah email sudah digunakan
        $check_email_query = "SELECT * FROM user WHERE email = '$email_reg'";
        $check_email_result = $conn->query($check_email_query);

        if ($check_email_result->num_rows > 0) {
            $error_message_reg = "Email Sudah Digunakan oleh pengguna lain, silakan gunakan email yang berbeda.";
        } else {
            // Query untuk memeriksa apakah username sudah digunakan
            $check_username_query = "SELECT * FROM user WHERE username = '$username_reg'";
            $check_username_result = $conn->query($check_username_query);

            if ($check_username_result->num_rows > 0) {
                $error_message_reg = "Username Sudah Digunakan oleh pengguna lain, silakan pilih username yang berbeda.";
            } else {
                // Hash the password before storing it in the database
                $hashed_password = password_hash($password_reg, PASSWORD_DEFAULT);

                // Insert data pengguna baru ke database
                $insert_query = "INSERT INTO user (email, username, password) VALUES ('$email_reg', '$username_reg', '$hashed_password')";
                $insert_result = $conn->query($insert_query);

                if ($insert_result) {
                    // Redirect ke halaman login setelah pendaftaran berhasil
                    header("Location: login.php");
                    exit();
                } else {
                    $error_message_reg = "Gagal melakukan pendaftaran. Silakan coba lagi.";
                }
            }
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en" class="register-page">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="img/logo2/logokecil2.png">
    <title>Register</title>
    <!-- Tambahkan stylesheet sesuai kebutuhan Anda -->
    <style>
    /* Tambahkan stylesheet sesuai kebutuhan Anda */
    @import url('css/stylelogin.css');
    @import url('css/styleutama.css');
    </style>
</head>
<body class="">
    <div id="background-container"></div>
    <div id="content"><a href="index.php">
        <img src="img/logo2/logoetam2.png" alt="Logo" id="logo"></a>
        <div id="top-right-links">
            <a href="tentang.php">About Us</a>
            <a href="kontak_kita.php">Contact</a>
        </div>
    <div class="grid">
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="form login">
        <div class="judul"><a href="register.php" class="b">REGISTER</a></div>       
            <?php
                // Tambahkan bagian ini untuk menampilkan pesan kesalahan registrasi
                if (!empty($error_message_reg)) {
                    echo '<p style="color: red; text-align: center;">' . $error_message_reg . '</p>';
                }
            ?>
            <div class="form__field">
                <label for="email"><svg class="icon">
                    <use xlink:href="#icon-envelope"></use>
                </svg><span class="hidden">Email</span></label>
                <input type="email" id="email" name="email_reg" value="<?php echo $email_reg; ?>" placeholder="Email" required>
            </div>
            <div class="form__field">
                <label for="username_reg"><svg class="icon">
                        <use xlink:href="#icon-user"></use>
                    </svg><span class="hidden">Username</span></label>
                <input type="text" id="username_reg" name="username_reg" value="<?php echo $username_reg; ?>" placeholder="Username" required>
            </div>
            <div class="form__field">
                <label for="password_reg"><svg class="icon">
                        <use xlink:href="#icon-lock"></use>
                    </svg><span class="hidden">Password</span></label>
                <input type="password" id="password_reg" name="password_reg" placeholder="Password" required>
            </div>
            <div class="form__field">
                <label for="confirm_password_reg"><svg class="icon">
                        <use xlink:href="#icon-lock"></use>
                    </svg><span class="hidden">Password</span></label>
                <input type="password" id="confirm_password_reg" name="confirm_password_reg" placeholder="Confirm Password" required>
            </div>
            <div class="form__field">
                <input type="submit" value="Register" name="register">
            </div><hr class="divider2"><p class="text--center">Already have an account? <a href="login.php" class="blue-link">Sign in</a> <svg class="icon">
                <use xlink:href="#icon-arrow-right"></use>
            </svg></p>
        </form>
    </div>
    <svg xmlns="http://www.w3.org/2000/svg" class="icons">
        <symbol id="icon-arrow-right" viewBox="0 0 1792 1792">
            <path d="M1600 960q0 54-37 91l-651 651q-39 37-91 37-51 0-90-37l-75-75q-38-38-38-91t38-91l293-293H245q-52 0-84.5-37.5T128 1024V896q0-53 32.5-90.5T245 768h704L656 474q-38-36-38-90t38-90l75-75q38-38 90-38 53 0 91 38l651 651q37 35 37 90z" />
        </symbol>
        <symbol id="icon-lock" viewBox="0 0 1792 1792">
            <path d="M640 768h512V576q0-106-75-181t-181-75-181 75-75 181v192zm832 96v576q0 40-28 68t-68 28H416q-40 0-68-28t-28-68V864q0-40 28-68t68-28h32V576q0-184 132-316t316-132 316 132 132 316v192h32q40 0 68 28t28 68z" />
        </symbol>
        <symbol id="icon-user" viewBox="0 0 1792 1792">
            <path d="M1600 1405q0 120-73 189.5t-194 69.5H459q-121 0-194-69.5T192 1405q0-53 3.5-103.5t14-109T236 1084t43-97.5 62-81 85.5-53.5T538 832q9 0 42 21.5t74.5 48 108 48T896 971t133.5-21.5 108-48 74.5-48 42-21.5q61 0 111.5 20t85.5 53.5 62 81 43 97.5 26.5 108.5 14 109 3.5 103.5zm-320-893q0 159-112.5 271.5T896 896 624.5 783.5 512 512t112.5-271.5T896 128t271.5 112.5T1280 512z" />
        </symbol>
        <symbol id="icon-envelope" viewBox="0 0 24 24">
        <path d="M21 5H3c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zM12 13L3 8V7l9 5 9-5v1l-9 5zm0-5L3 3h18l-9 5z"/>
    </symbol>
    </svg>
    <script src="js/utama3.js"></script>
    <script src="js/utama4.js"></script>
</body>
</html>
